# Encord Segment Numbers 0.4.2

Remove the old extension, extract this ZIP, then Load unpacked in chrome://extensions. Select the folder directly containing manifest.json. Refresh Encord.

Matches only [data-testid="vla-range-bar"][data-track-id="detailed"]. Reads data-range-start and data-range-end. Groups duplicate representations with the same classification hash and range. Sorts by start, end, then classification hash. Handles and text labels are not counted. Labels update after range edits, DOM changes, scrolling and resizing.

Accuracy limitation: numbers are ranks among unique range bars currently present in the page, not a verified full-task list. If Encord virtualizes/unmounts off-screen ranges, ranks and count can change. No historical cache is used because that would retain deleted segments. Overlapping ranges are counted separately when their hash or bounds differ; identical hash/bounds are treated as one range. Label positions use the visible clipped bar region. All visible numbers share one horizontal baseline. Crowded labels move horizontally, with thin connector lines to their segments. If the viewport cannot physically fit all labels, overlap may remain; zoom in for readability.

No Encord API, credentials, network interception, or annotation changes. Exact selector based on user-supplied HTML; not tested in authenticated Encord. Local Node tests cover the exact selector, sorting 40 range records, duplicate representations, distinct classifications, hidden bars, invalid attributes, deletion and range edits. JavaScript syntax checks pass. Pure layout tests also verify a shared baseline and collision spacing. Browser layout testing was unavailable because this environment has no installed Chromium binary. Positioning, clipping and Chrome installation remain unverified.

0.4.2: version-specific runtime prevents reuse of the old staggered script. Old v3 overlay is hidden. All badges have CSS top:0 inside one shared positioned row. Remove prior extension versions and refresh the task after installation.
